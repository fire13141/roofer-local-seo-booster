=== Roofer Local SEO Booster ===
Contributors: alfredobgrabowski
Tags: roofer seo, local seo, roofing schema, image exifr, seo booster, spam protection, lead generation, anti-spam, webp converter
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lightweight, zero-config high performance Booster for Residential & Commercial Roofing SEO. Strips image EXIF data, transcodes to WebP (75% quality), blocks lead-scam agencies & AI robocall bots via honeypots, auto-injects local RoofingContractor schema, and appends a regional Trust & Verification Badge.

== Description ==

* **Supported WordPress Versions**: WordPress 5.0, 5.8, 5.9, 6.0, 6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 6.7 (Optimized for Gutenberg & Classic Editors)
* **Supported PHP Versions**: PHP 7.4, 8.0, 8.1, 8.2, 8.3

Deploy a zero-overhead local lead acquisition engine in minutes. This lightweight, elite-grade WordPress plugin bypasses expensive marketing retainers and spam-lead brokers. It automatically manages Google-compliant schema injections, optimizes image deliverables, enforces 301 rules, and protects your inbox from robo-spam. Compatible with standard builders (Gutenberg, Elementor, Divi) and PHP environments.

== Primary Commercial Advantages ==

* **Zero-Commission Lead Pipeline**: Lead submissions bypass third-party middleman brokers (Angie's List, Thumbtack, Networx) and land directly in your email inbox at no charge. Keep 100% of your roof replacement and repair profits.
* **Dual-Layer Spambot & Scam Mail Shield**: Injects invisible, bulletproof Honeypot validation filters to identify bot scraping activity, and uses real-time keyphrase regex heuristic analysis to forcefully terminate pitch and scam emails before they hit your inbox.
* **Auto Local-Business Schema Injections**: Auto-injects Google-compliant RoofingContractor and LocalBusiness structured JSON-LD schemas inside the page head based on standard NAP (Name, Address, Phone) consistency.
* **EXIF Coordinate Extraction & WebP Pipelines**: Strip sensitive EXIF tracking data from subcontractor/worker phone-captured job thumbnails, automatically compress to ultra-fast WebP format with 75% resolution ratios, and improve core web vitals.
* **Built-In Customer Financing Slots**: Seamless, deep-linked portals with Joist or Service Finance integrations. Customers apply for 0% credit lines independently. You stay out of the banking math. No configurations/APIs required.

== Installation ==

= Dashboard Upload =
1. Download the compiled zip package: `roofer-local-seo-booster.zip`
2. Connect to your WordPress Admin dashboard (`/wp-admin`).
3. Click on the left-side panel **Plugins** -> **Add New**.
4. Press the **Upload Plugin** button at the top header.
5. Select `roofer-local-seo-booster.zip`, execute **Install Now**, and once successfully installed, select **Activate Plugin**.

= Manual FTP =
1. Extract `roofer-local-seo-booster.zip` to your local computer.
2. Log into your hosting web server via a preferred FTP program (e.g., FileZilla).
3. Navigate to the core plugin repository path: `wp-content/plugins/`.
4. Upload the extracted folder `roofer-local-seo-booster` directly to this directory.
5. Access your WordPress dashboard plugin list, search for **Roofer Local SEO Booster**, and select **Activate**.

== Settings ==

Once activated, access your dedicated control desk:
1. Navigate to Left Menu -> **Settings** -> **Roofer SEO Booster**.
2. **Local Business Credentials (SEO Trust Badge)**:
   * State License Number (e.g., `FL-ROOF-2026-PROjklakak`)
   * General Liability Details (e.g., `Fully Covered up to $5,000,000`)
   * Google Business profile NAP Address (e.g., `550 S Orange Ave, Orlando, FL 32801`)
   * Customer Inquiries Phone (e.g., `1-800-555-ROOF-738`)
3. **Zero-Headache Financing Links**:
   * Joist Partner ID / Link or Service Finance Dealer ID
4. **Local Lead Notification Email**:
   * Inquiries receipt email (e.g., `3973178349@qq.com`)
5. Press **Save Credentials & Refresh Rules** to complete deployment and flush WordPress permalinks automatically.

== Shortcodes ==

You can place these highly responsive shortcodes on any page, post, or widget area:

* `[roofer_lead_form]` - Custom direct estimate and project verification contact form.
* `[roofer_trust_badge]` - Local liability compliance badge containing state license and guarantee credentials.
* `[roofer_financing]` - 0% financing section integrating Joist and Service Finance dealer gateways.

== Verification ==

Easily verify the pristine operations of all core engines within 60 seconds:

= 1. Lead Submissions & Spambot Defense Testing =
* Put `[roofer_lead_form]` on any test page. Try sending empty fields or typing promotional messages such as "AI auto-scheduling" or "chatbot marketing". The defense shield immediately terminates the submission, displaying a clear block error.

= 2. Local SEO JSON-LD Source Validation =
* Press `Ctrl + U` (or View Page Source) on your home page, look for `application/ld+json`. Your license details, NAP configurations, and RoofingContractor local targets are perfectly rendered.

= 3. WebP Media Compressor & GPS Privacy Checker =
* Upload a phone photo containing GPS trackers to **Media** -> **Add New**. The file instantly transforms into `.webp`, drops up to 80% weight, and is stripped of tracking location data to protect user privacy.

== Frequently Asked Questions ==

= Can I use this for non-roofing local services? =
It is pre-optimized with RoofingContractor schemas out of the box, but you can target any local service by putting your custom details on the credentials page.

= Will this conflict with Yoast SEO or RankMath? =
Not at all. This runs in parallel, specifically injecting the highly requested RoofingContractor schema that standard general SEO suites omit.

== Support ==

If you experience layout conflicts, need assistance hooking custom forms, or require bespoke adjustments:
* **Developer Support Inbox**: 3973178349@qq.com
* **SLA Response Commitment**: Within 12-24 business hours as part of our premium contractor guarantee.
